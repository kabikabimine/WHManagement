const moment = require('moment');
const axios = require('axios');

const totalPeople = 9; // Tổng số người
const myPosition = 9; // Vị trí của bạn
const startDate = moment('2024-10-08'); // Ngày bạn phải gửi từ tiếng Anh

const telegramToken = '7797981830:AAFKv1SrdaXnDM2M-njrUOzSILR0J74P27o'; // Thay thế bằng token của bạn
const chatId = '1873755848'; // Thay thế bằng ID người nhận

// Hàm gửi thông báo qua Telegram
async function sendTelegramMessage(message) {
    const url = `https://api.telegram.org/bot${telegramToken}/sendMessage`;
    try {
        await axios.post(url, {
            chat_id: chatId,
            text: message
        });
        console.log('Thông báo đã được gửi qua Telegram');
    } catch (error) {
        console.error('Lỗi khi gửi thông báo:', error);
    }
}

// Hàm tính toán ngày gửi tiếp theo
function calculateNextDate(currentDate) {
    let nextDate = currentDate.clone().add(totalPeople, 'days'); // Thêm số ngày bằng số người
    // Bỏ qua thứ 7 và chủ nhật
    while (nextDate.isoWeekday() > 5) {
        nextDate.add(1, 'days'); // Nếu là thứ 7 hoặc chủ nhật, thêm một ngày
    }
    return nextDate;
}

// Kiểm tra ngày hôm nay có phải là ngày bạn gửi không
function isTodayReminderDay() {
    const today = moment(); // Lấy ngày hôm nay
    return today.isSame(startDate, 'day');
}

// Hàm kiểm tra giờ và gửi thông báo nếu là 8h, 9h hoặc 10h sáng
async function checkAndSendReminder() {
    if (isTodayReminderDay()) {
        const now = moment(); // Lấy thời gian hiện tại
        const hour = now.hour(); // Lấy giờ hiện tại

        // Kiểm tra nếu giờ hiện tại là 8h, 9h hoặc 10h sáng
        if (hour === 8 || hour === 9 || hour === 10) {
            const nextDate = calculateNextDate(startDate); // Tính toán ngày gửi tiếp theo
            const formattedNextDate = nextDate.format('DD/MM/YYYY'); // Định dạng ngày gửi tiếp theo
            const message = `Hôm nay là ngày bạn gửi từ tiếng Anh! Giờ hiện tại: ${hour}h sáng.\nNgày gửi tiếp theo của bạn là: ${formattedNextDate}`;
            
            // Gửi thông báo qua Telegram
            await sendTelegramMessage(message);
        }
    }
}

// Lên lịch kiểm tra mỗi phút để gửi thông báo
setInterval(checkAndSendReminder, 60 * 1000); // Kiểm tra mỗi phút
